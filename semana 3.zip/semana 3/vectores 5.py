
numero = [1,2,3,4,5,6,7,8,9,10]
resultado = 0
a =int(input("ingrse un numero: "))
if numero[a-1] == a:
    resultado = a
    print (resultado)
    

