from funciones_vectores import buscar
posicion=0
array=[1,2,3,4,5]
numero=int(input("ingrese un numero a buscar: "))

buscar(array, numero)


    
