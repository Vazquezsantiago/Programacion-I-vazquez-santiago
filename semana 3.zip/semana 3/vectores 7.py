array= [1,2,3,4,5,6]
for i in range (len(array)):
    print (array[-1-i])
    