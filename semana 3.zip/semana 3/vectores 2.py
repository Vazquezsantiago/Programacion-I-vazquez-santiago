array = [0]*10

suma =0

for i in range(len(array)):
    numero = int(input("ingrese un numero: "))
    suma += numero

print(f"la suma es:{suma}")
