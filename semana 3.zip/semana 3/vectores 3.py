numero = [0.0]*6
suma =0
for a in range(len(numero)):
   a = float(input("ingrese un numero"))
   suma += a
   promedio = (suma/(len(numero)))
print(promedio)